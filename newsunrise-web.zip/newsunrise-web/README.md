# New Sunrise Turismo · Landing web

Página web de New Sunrise Turismo (Huacachina · Ica · Perú): full days, sobrevuelo a las Líneas de Nazca, rutas del pisco y traslados.

## Contenido

- `index.html`: la página completa (HTML, CSS y JavaScript en un solo archivo, sin dependencias).
- `img/`: fotos y logo optimizados.

## Publicar en GitHub Pages

1. Crea un repositorio nuevo en GitHub (por ejemplo `newsunrise-web`).
2. Sube `index.html`, `README.md` y la carpeta `img/` a la raíz del repositorio (botón **Add file → Upload files**).
3. Entra a **Settings → Pages**, en *Source* elige **Deploy from a branch**, rama `main` y carpeta `/ (root)`, y guarda.
4. En uno o dos minutos la web estará en `https://TU-USUARIO.github.io/newsunrise-web/`.

Para usar un dominio propio, escríbelo en **Settings → Pages → Custom domain** y crea en tu proveedor de dominio un registro CNAME que apunte a `TU-USUARIO.github.io`.

## Editar datos

- WhatsApp principal: busca `51978906482` en `index.html` (aparece en los enlaces y en la constante `PHONE` del script final).
- Segundo WhatsApp: `51933475976`.
- Correo: `newsunrise.turismo@gmail.com`.
- Precios y lo que incluye cada tour: tarjetas de la sección `#tours` y la lista `TOURS` del script final (cambia ambos).
